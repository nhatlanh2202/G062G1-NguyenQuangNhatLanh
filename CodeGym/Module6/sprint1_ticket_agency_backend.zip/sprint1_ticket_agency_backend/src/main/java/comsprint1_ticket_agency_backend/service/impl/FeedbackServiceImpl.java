package comsprint1_ticket_agency_backend.service.impl;

import comsprint1_ticket_agency_backend.entity.Feedback;
import comsprint1_ticket_agency_backend.repository.FeedbackRepository;
import comsprint1_ticket_agency_backend.service.FeedbackService;
import comsprint1_ticket_agency_backend.service.search.FeedbackSpecification;
import comsprint1_ticket_agency_backend.service.search.SearchCriteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;



import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;


@Service
public class FeedbackServiceImpl implements FeedbackService {

    @Autowired
    FeedbackRepository feedbackRepository;



    @Override
    public Page<Feedback> findAll(int page) {
        Pageable pageable = PageRequest.of(page - 1, 4, Sort.by("id"));
        Page<Feedback> feedbacks = feedbackRepository.findAll(pageable);
        return feedbacks;
    }
//    @Override
//    public List<Feedback> findAll() {
//        List<Feedback> feedbacks = feedbackRepository.findAll();
//        return feedbacks;
//    }




    @Override
    public Feedback findById(Long id) {
        return feedbackRepository.findById(id).orElse(null);
    }

    @Override
    public void save(Feedback feedback) {
        this.feedbackRepository.save(feedback);
    }

    @Override
    public Specification<Feedback> getFilter(String senderName, String sendDate, String processStatus) {
        List<FeedbackSpecification> specs = new ArrayList<>();
        Specification<Feedback> spec;
        if (!"".equals(senderName) && !"undefined".equals(senderName)){
            specs.add(new FeedbackSpecification(new SearchCriteria("senderName", "like", senderName)));
        }
        if (!"".equals(sendDate) && !"undefined".equals(sendDate)){
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate dateTime = LocalDate.parse(sendDate, formatter);
            System.out.println(dateTime instanceof LocalDate);
            specs.add(new FeedbackSpecification(new SearchCriteria("sendDate", "equal", sendDate)));
        }
        if (!"".equals(processStatus) && !"undefined".equals(processStatus)){
            specs.add(new FeedbackSpecification(new SearchCriteria("processStatus", "equal", processStatus)));
        }
        if (specs.size() !=0){
            spec = Specification.where(specs.get(0));
            for (int i = 1; i < specs.size(); i++){
                assert spec != null;
                spec = spec.and(specs.get(i));
            }
            return spec;
        }
        return null;
    }




    @Override
    public Page<Feedback> findFeedbackByCriteria(Specification<Feedback> specs, int page) {
        Pageable pageable = PageRequest.of(page - 1, 4);
        Page<Feedback> feedbackPages = feedbackRepository.findAll(specs, pageable);
        return feedbackPages;
    }
//    @Override
//    public List<Feedback> findFeedbackByCriteria(Specification<Feedback> specs) {
//        List<Feedback> feedbackPages = feedbackRepository.findAll(specs);
//        return feedbackPages;
//    }



    @Override
    public List<Feedback> findAllFeedback() {
        return feedbackRepository.findAll();
    }
}
