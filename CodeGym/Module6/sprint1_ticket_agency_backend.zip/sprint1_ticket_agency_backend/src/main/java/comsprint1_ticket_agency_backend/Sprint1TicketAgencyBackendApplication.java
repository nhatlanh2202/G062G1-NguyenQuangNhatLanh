package comsprint1_ticket_agency_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sprint1TicketAgencyBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(Sprint1TicketAgencyBackendApplication.class, args);
    }

}
