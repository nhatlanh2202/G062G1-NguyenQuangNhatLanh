package comsprint1_ticket_agency_backend.controller;



import comsprint1_ticket_agency_backend.entity.Feedback;
import comsprint1_ticket_agency_backend.service.EmailService;
import comsprint1_ticket_agency_backend.service.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/api/v1")
public class FeedbackController {
    @Autowired
    private FeedbackService feedbackService;

//    @Autowired
//    private EmailService emailService;

    @GetMapping("/admin/feedback-page")
    public ResponseEntity<Page<Feedback>> getAllFeedback(
            @RequestParam("page") int page,
            @RequestParam(name = "senderName", defaultValue = "") String senderName,
            @RequestParam(name = "sendDate", defaultValue = "") String sendDate,
            @RequestParam(name = "processStatus", defaultValue = "") String processStatus){
        Specification<Feedback> search = feedbackService.getFilter(senderName, sendDate, processStatus);
        System.out.println(processStatus instanceof String);
        Page<Feedback> feedbackPages;
        if (search != null) {
            feedbackPages = feedbackService.findFeedbackByCriteria(search, page);
        }
        else {
            feedbackPages = feedbackService.findAll(page);
        }
        if (feedbackPages.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(feedbackPages);
    }

//    @GetMapping("/admin/feedback-page")
//    public ResponseEntity<List<Feedback>> getAllFeedback(
//            @RequestParam(name = "senderName", defaultValue = "") String senderName,
//            @RequestParam(name = "sendDate", defaultValue = "") String sendDate,
//            @RequestParam(name = "processStatus", defaultValue = "") String processStatus){
//        Specification<Feedback> search = feedbackService.getFilter(senderName, sendDate, processStatus);
//        List<Feedback> feedbackPages;
//        if (search != null) {
//            feedbackPages = feedbackService.findFeedbackByCriteria(search);
//        }
//        else {
//            feedbackPages = feedbackService.findAll();
//        }
//        if (feedbackPages.isEmpty()){
//            return ResponseEntity.noContent().build();
//        }
//        return ResponseEntity.ok(feedbackPages);
//    }

//    @RequestMapping(value = "/admin/feedback-send/{id}", method = RequestMethod.POST)
//    public ResponseEntity<Void> changePassword(@PathVariable(name = "id") Long id, @RequestBody Feedback feedback) {
//        feedback = feedbackService.findById(id);
//        feedback.setProcessStatus(true);
//        String email = feedback.getSenderEmail();
//        feedbackService.save(feedback);
//        SimpleMailMessage passwordResetEmail = new SimpleMailMessage();
//        passwordResetEmail.setFrom("C0620g1@gmail.com");
//        passwordResetEmail.setTo(email);
//        passwordResetEmail.setSubject("LanhIsMe");
//        passwordResetEmail.setTo("Cảm ơn quý khách đã góp ý về ứng dụng Airline mới \n" +
//                "của doanh nghiệp chúng tôi. Công ty chúng tôi sẽ cố gắng xem xét và xử lý vấn đề của quý khách \n" +
//                "trong thời gian sớm nhất để có sản phẩm vừa lòng quý khách.\n" +
//                "Một lần nữa, cảm ơn vì phản hồi của quý khách.\n" +
//                "Trân trọng,");
//        emailService.sendEmail(passwordResetEmail);
//        HttpHeaders headers = new HttpHeaders();
//        return new ResponseEntity<>(headers, HttpStatus.CREATED);
//    }



    @GetMapping("/admin/feedback-list")
    public ResponseEntity<List<Feedback>> getFeedbackList(){
        List<Feedback> feedbackList;
        feedbackList = feedbackService.findAllFeedback();
        return ResponseEntity.ok(feedbackList);
    }

//    @PutMapping("/admin/feedback/{id}")
//    private ResponseEntity<Feedback> updateFeedback(@PathVariable("id") long id, @RequestBody Feedback feedback){
//        feedback.setProcessStatus(true);
//        feedbackService.save(feedback);
//        HttpHeaders headers = new HttpHeaders();
//        return new ResponseEntity<Feedback>(headers, HttpStatus.CREATED);
//    }

}
