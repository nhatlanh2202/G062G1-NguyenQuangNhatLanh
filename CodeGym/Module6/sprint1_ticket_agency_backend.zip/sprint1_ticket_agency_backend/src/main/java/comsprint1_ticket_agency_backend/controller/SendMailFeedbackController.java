package comsprint1_ticket_agency_backend.controller;


import comsprint1_ticket_agency_backend.entity.Feedback;
import comsprint1_ticket_agency_backend.service.EmailService;
import comsprint1_ticket_agency_backend.service.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/admin/send-feedback")
public class SendMailFeedbackController {
    @Autowired
    private FeedbackService feedbackService;

    @Autowired
    private EmailService emailService;

    @GetMapping("/lanh/{kute}")
    public ResponseEntity<Void> changePassword(@PathVariable String kute) {
//        Feedback feedback = feedbackService.findById(id);
//        feedback.setProcessStatus(true);
//        String email = feedback.getSenderEmail();
//        feedbackService.save(feedback);
        SimpleMailMessage sendFeedback = new SimpleMailMessage();
        sendFeedback.setFrom("C0620g1@gmail.com");
        sendFeedback.setTo("nhatlanh2202@gmail.com");
        sendFeedback.setSubject("LanhIsMe");
        sendFeedback.setText("ok nha !" + kute);
        emailService.sendEmail(sendFeedback);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}
