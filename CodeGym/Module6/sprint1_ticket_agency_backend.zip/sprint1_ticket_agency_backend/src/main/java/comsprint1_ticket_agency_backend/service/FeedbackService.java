package comsprint1_ticket_agency_backend.service;


import comsprint1_ticket_agency_backend.entity.Feedback;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;

public interface FeedbackService {
        Page<Feedback> findAll(int page);
//    List<Feedback> findAll();

    Feedback findById(Long id);

    void save(Feedback feedback);

    Specification<Feedback> getFilter(String senderName, String sendDate, String processStatus);

        Page<Feedback> findFeedbackByCriteria(Specification<Feedback> spec, int page);
//    List<Feedback> findFeedbackByCriteria(Specification<Feedback> spec);

    List<Feedback> findAllFeedback();
}
