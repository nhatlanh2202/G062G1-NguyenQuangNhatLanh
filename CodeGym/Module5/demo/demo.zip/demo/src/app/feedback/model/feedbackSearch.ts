export interface FeedbackSearch {
  senderName: string;
  sendDate: string;
  processStatus: boolean;
}
