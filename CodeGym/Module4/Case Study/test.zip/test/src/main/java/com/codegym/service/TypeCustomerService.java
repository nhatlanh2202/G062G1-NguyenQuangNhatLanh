package com.codegym.service;

import com.codegym.entity.CustomerType;

import java.util.List;


public interface TypeCustomerService {
    List<CustomerType> findAll();
}
