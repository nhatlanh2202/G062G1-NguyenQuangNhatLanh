package com.codegym.repository;

public interface demo {
    //    @Query(value = "select * from customer where name like %:keyword% or address like %:keyword% or phone_number like %:keyword%",nativeQuery = true)
//
//    Page<Customer> findAllByAll(@Param("keyword") String keyword, Pageable pageable);
//
//
//    Page<Customer> findByNameContaining(Pageable pageable, String name);
//
//    Page<Customer> findByAddressContainingOrEmailContaining(Pageable pageable, String name);

//    @Query(value = "select * from customer where name like %:keyword%", nativeQuery = true)
//    Page<Customer> findAllByAllName(@Param("keyword") String keyword, Pageable pageable);

//    @Query(value = "select * from customer where name like %?1%", nativeQuery = true)
//    Page<Customer> findAllByAllName(Pageable pageable, String keyword);

//    @Query(value = "select * from customer where address like %:keyword% or email like %:keyword%", nativeQuery = true)
//    Page<Customer> findCustomerByAddressAndEmail(@Param("keyword") String keyword, Pageable pageable);
}
